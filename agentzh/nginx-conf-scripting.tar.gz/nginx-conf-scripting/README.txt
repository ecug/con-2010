README
=======

Please use Mozilla Firefox to open the .xul file in this directory.
Some versions of Mozilla Suit is known to have problems with local
.xul files.

Enjoy!
-agentzh
