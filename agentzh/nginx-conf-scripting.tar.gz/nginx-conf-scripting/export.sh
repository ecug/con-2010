#!/bin/bash

outdir=~/hack/slides/xulapp/
cp -vr images $outdir 
cp -v xulapp.xul $outdir
cp -v xulapp.sld $outdir
cp -vr css $outdir
cp -vr lib $outdir

